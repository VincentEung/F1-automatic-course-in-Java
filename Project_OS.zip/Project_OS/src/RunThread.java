import java.util.Random;

public class RunThread implements Runnable {
        String name;
        int total_time=0;

        Random rand = new Random();
        double random_time = 1+rand.nextDouble(1000);

        public RunThread(String name) {
            this.name = name;
        }

        public int getTotal_time() {
            return total_time;
        }

    @Override
        public void run() {
            try {
                total_time += random_time;
                for (int i = 0; i < 3; i++) {
                    Thread.sleep((long) random_time);
                    System.out.println("Round number : " + i + " ; " + name + "  had made this time score: " + random_time);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Pilot " + name + ": has finished the course!");
        }
    }