public class Main {
    public static void main(String[] args) {

        RunThread p1 = new RunThread("Ocon");
        RunThread p2 = new RunThread("Hamilton");
        RunThread p3 = new RunThread("Leclerc");

        Thread t1 = new Thread(p1);
        Thread t2 = new Thread(p2);
        Thread t3 = new Thread(p3);

        t1.start();
        t2.start();
        t3.start();

        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("The course has ended !! ");

        if (p1.total_time< p2.total_time && p1.total_time< p3.total_time){
            System.out.println("The winner is :" + p1.name);
        } else if (p2.total_time< p1.total_time && p2.total_time< p3.total_time) {
            System.out.println("The winner is :" + p2.name);
        }else if (p3.total_time< p1.total_time && p3.total_time< p2.total_time){
            System.out.println("The winner is :" + p3.name);
        }
    }
}
